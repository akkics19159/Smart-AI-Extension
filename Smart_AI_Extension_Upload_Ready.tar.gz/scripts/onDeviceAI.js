
// onDeviceAI.js - Handles on-device inference using Transformers.js (Completely Free)

import { pipeline, env } from 'https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.1';

// Optimized for web extensions - skip local model checks
env.allowLocalModels = false;

// Singleton classes for different AI tasks
class SummarizationPipeline {
    static task = 'summarization';
    static model = 'Xenova/distilbart-cnn-6-6';
    static instance = null;

    static async getInstance(progress_callback = null) {
        if (this.instance === null) {
            this.instance = pipeline(this.task, this.model, { progress_callback });
        }
        return this.instance;
    }
}

class QuestionAnsweringPipeline {
    static task = 'question-answering';
    static model = 'Xenova/distilbert-base-uncased-distilled-squad';
    static instance = null;

    static async getInstance(progress_callback = null) {
        if (this.instance === null) {
            this.instance = pipeline(this.task, this.model, { progress_callback });
        }
        return this.instance;
    }
}

class TextGenerationPipeline {
    static task = 'text-generation';
    static model = 'Xenova/gpt2';
    static instance = null;

    static async getInstance(progress_callback = null) {
        if (this.instance === null) {
            this.instance = pipeline(this.task, this.model, { progress_callback });
        }
        return this.instance;
    }
}

/**
 * Summarizes text using on-device AI
 */
export async function summarize(text, progressCallback) {
    try {
        const summarizer = await SummarizationPipeline.getInstance(progressCallback);

        const output = await summarizer(text, {
            max_new_tokens: 100,
            min_new_tokens: 30,
            truncation: true,
        });

        if (output && output.length > 0 && output[0].summary_text) {
            return output[0].summary_text;
        } else {
            throw new Error("Summarization failed - unexpected output format");
        }
    } catch (error) {
        console.error("Summarization error:", error);
        throw error;
    }
}

/**
 * Generates flashcards using on-device AI (Optimized for Speed)
 */
export async function generateFlashcard(text, progressCallback) {
    try {
        // Ultra-fast processing - minimal memory usage
        const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 5);

        if (sentences.length < 1) {
            return {
                question: "What is the main point?",
                answer: text.substring(0, 150) + (text.length > 150 ? "..." : ""),
                originalText: text,
                timestamp: Date.now()
            };
        }

        // Memory-efficient processing
        const firstSentence = sentences[0].trim();
        const question = firstSentence.length > 60
            ? `What does the text say about "${firstSentence.substring(0, 60)}..."?`
            : `What does the text say about "${firstSentence}"?`;

        // Combine 1-2 sentences for answer (memory efficient)
        const answerSentences = sentences.slice(1, Math.min(3, sentences.length));
        const answer = answerSentences.join('. ').trim();
        const finalAnswer = answer || "The text discusses this topic in detail.";

        return {
            question: question,
            answer: finalAnswer + (finalAnswer.endsWith('.') ? '' : '.'),
            originalText: text,
            timestamp: Date.now()
        };
    } catch (error) {
        console.error("Flashcard generation error:", error);
        return {
            question: "What is discussed in this text?",
            answer: text.substring(0, 120) + "...",
            originalText: text,
            timestamp: Date.now()
        };
    }
}

/**
 * Generates quiz questions using on-device AI (Optimized for Speed)
 */
export async function generateQuiz(text, questionCount = 3) {
    try {
        // Memory-efficient sentence processing
        const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 8);

        if (sentences.length < 2) {
            // Ultra-fast fallback for short text
            return [{
                id: 1,
                question: "What is the main topic of this text?",
                options: [
                    "The primary subject discussed",
                    "An unrelated topic",
                    "Something different",
                    "Content not mentioned"
                ],
                correct: 0,
                originalText: text,
                timestamp: Date.now()
            }];
        }

        const quiz = [];
        const usedIndices = new Set();

        // Limit questions to prevent memory issues
        const maxQuestions = Math.min(questionCount, Math.min(sentences.length, 5));

        // Pre-defined distractors (memory efficient)
        const distractors = [
            "An unrelated concept",
            "Something not mentioned",
            "A different topic",
            "External information"
        ];

        for (let i = 0; i < maxQuestions; i++) {
            // Simple random selection
            let sentenceIndex = Math.floor(Math.random() * sentences.length);
            if (usedIndices.has(sentenceIndex)) {
                sentenceIndex = (sentenceIndex + 1) % sentences.length;
            }
            usedIndices.add(sentenceIndex);

            const sentence = sentences[sentenceIndex].trim();
            const question = sentence.length > 45
                ? `What does the text say about "${sentence.substring(0, 45)}..."?`
                : `What does the text say about "${sentence}"?`;

            // Create options array efficiently
            const options = [sentence, ...distractors.slice(0, 3)];

            // Simple shuffle (Fisher-Yates, memory efficient)
            for (let j = options.length - 1; j > 0; j--) {
                const k = Math.floor(Math.random() * (j + 1));
                [options[j], options[k]] = [options[k], options[j]];
            }

            const correctIndex = options.indexOf(sentence);

            quiz.push({
                id: i + 1,
                question: question,
                options: options,
                correct: correctIndex,
                originalText: text,
                timestamp: Date.now()
            });
        }

        return quiz;
    } catch (error) {
        console.error("Quiz generation error:", error);
        return [{
            id: 1,
            question: "What is discussed in this text?",
            options: [
                "The main topic",
                "Something else",
                "Unrelated content",
                "External information"
            ],
            correct: 0,
            originalText: text,
            timestamp: Date.now()
        }];
    }
}


// onDeviceAI.js - Handles on-device inference using Transformers.js

// Import the pipeline function from the Transformers.js library
import { pipeline, env } from 'https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.1';

// Skip local model checks for a smoother, web-first experience.
// This is a recommended optimization for web extensions.
env.allowLocalModels = false;

/**
 * A singleton class to ensure we only ever instantiate the summarization pipeline once.
 */
class SummarizationPipeline {
    static task = 'summarization';
    static model = 'Xenova/distilbart-cnn-6-6'; // A small, fast, and decent-quality model
    static instance = null;

    static async getInstance(progress_callback = null) {
        if (this.instance === null) {
            this.instance = pipeline(this.task, this.model, { progress_callback });
        }
        return this.instance;
    }
}

/**
 * Summarizes the given text using an on-device model.
 * @param {string} text The text to summarize.
 * @param {function} progressCallback A function to call with loading progress.
 * @returns {Promise<string>} The summarized text.
 */
export async function summarize(text, progressCallback) {
    try {
        // Get the summarization pipeline instance, passing the progress callback
        const summarizer = await SummarizationPipeline.getInstance(progressCallback);

        // Perform the summarization
        const output = await summarizer(text, {
            // Tweak parameters for better/faster results
            max_new_tokens: 100, // Limit the length of the summary
            min_new_tokens: 30,  // Ensure the summary is not too short
            truncation: true,    // Truncate input text if it's too long
        });

        // The output is an array, but we usually just want the first result.
        if (output && output.length > 0 && output[0].summary_text) {
            return output[0].summary_text;
        } else {
            throw new Error("Summarization model returned an unexpected output format.");
        }

    } catch (error) {
        console.error("Error during summarization:", error);
        // Re-throw the error to be caught by the caller in popup.js
        throw error;
    }
}

// In the future, we can add other AI functions here following the same pattern
// export async function generateQuiz(text, progressCallback) { ... }
// export async function generateFlashcards(text, progressCallback) { ... }
