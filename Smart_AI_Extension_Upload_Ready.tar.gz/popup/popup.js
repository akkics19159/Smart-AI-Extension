// SmartNotes AI Popup Script (Universal Summarizer)
import { summarize } from '../scripts/onDeviceAI.js';
import { getYouTubeTranscript } from '../scripts/youtubeManager.js';

/**
 * Performs OCR on the current tab's visible area
 * @param {number} tabId - The tab ID to capture
 * @returns {Promise<string>} Extracted text from the screen
 */
async function performScreenOCR(tabId) {
    return new Promise(async (resolve, reject) => {
        try {
            // Capture visible tab as image
            const screenshot = await chrome.tabs.captureVisibleTab(null, {
                format: 'png',
                quality: 100
            });

            // Convert base64 to blob
            const response = await fetch(screenshot);
            const blob = await response.blob();

            // Send to background script for OCR processing
            const result = await chrome.runtime.sendMessage({
                type: 'ocr_process',
                imageData: blob
            });

            if (result.success && result.data && result.data.text) {
                resolve(result.data.text);
            } else {
                reject(new Error('OCR failed to extract text'));
            }
        } catch (error) {
            console.error('Screen OCR error:', error);
            reject(error);
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    initializeTabs();
    initializeButtons();
    run();
});

function initializeButtons() {
    // Manual mode button
    document.getElementById('manualBtn').addEventListener('click', function() {
        enterManualMode();
    });

    // Settings button
    document.getElementById('settingsBtn').addEventListener('click', function() {
        chrome.runtime.openOptionsPage();
    });
}

async function enterManualMode() {
    showLoading("Select text on the page and try again...");

    try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]) {
            // Highlight that manual selection is needed
            await chrome.tabs.sendMessage(tabs[0].id, {
                action: "showManualMode"
            });

            // Close popup after a short delay
            setTimeout(() => {
                window.close();
            }, 2000);
        }
    } catch (error) {
        console.error('Manual mode error:', error);
    }

    hideLoading();
}

/**
 * Checks if a URL is a YouTube video page.
 * @param {string} url The URL to check.
 * @returns {string|null} The video ID if it's a YouTube video, otherwise null.
 */
function getYouTubeVideoId(url) {
    if (!url.includes("youtube.com/watch")) {
        return null;
    }
    try {
        const urlObj = new URL(url);
        return urlObj.searchParams.get("v");
    } catch (e) {
        return null;
    }
}

/**
 * Main function to orchestrate content extraction and AI processing.
 */
async function run() {
showLoading("🤖 SmartNotes AI: Detecting content automatically...");

try {
const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
if (!tabs || !tabs[0] || !tabs[0].id) {
showError("Could not access the active tab.");
return;
}

const activeTab = tabs[0];
const videoId = getYouTubeVideoId(activeTab.url);

let contentToSummarize = '';
        let contentSource = '';

if (videoId) {
// It's a YouTube video, get the transcript
showLoading("🎬 Auto-detecting YouTube video transcript...");
try {
    contentToSummarize = await getYouTubeTranscript(videoId);
contentSource = `YouTube Video (Auto-detected)`;
} catch (error) {
    showError(error.message || "Failed to get YouTube transcript.");
        return;
}
} else {
// Try multiple content sources for automatic detection
showLoading("📄 Auto-extracting page content...");

// First try to get page text
try {
const response = await chrome.tabs.sendMessage(activeTab.id, { action: "getPageContent" });
if (response && response.success && response.content) {
    contentToSummarize = response.content;
        contentSource = `Webpage Text (Auto-extracted)`;

    // If page text is too short, try OCR as fallback
        if (contentToSummarize.length < 200) {
                showLoading("📷 Page text short, trying OCR...");
                        try {
                            const ocrText = await performScreenOCR(activeTab.id);
                            if (ocrText && ocrText.length > contentToSummarize.length) {
                                contentToSummarize = ocrText;
                                contentSource = `Screen OCR (Auto-captured)`;
                            }
                        } catch (ocrError) {
                            console.log("OCR failed, using page text:", ocrError);
                        }
                    }
                } else {
                    // Page text failed, try OCR
                    showLoading("📷 Auto-capturing screen content...");
                    try {
                        contentToSummarize = await performScreenOCR(activeTab.id);
                        contentSource = `Screen OCR (Auto-captured)`;
                    } catch (ocrError) {
                        showError("Could not extract content from page or screen.");
                        return;
                    }
                }
            } catch (error) {
                // Try OCR as last resort
                showLoading("📷 Attempting screen capture...");
                try {
                    contentToSummarize = await performScreenOCR(activeTab.id);
                    contentSource = `Screen OCR (Auto-captured)`;
                } catch (finalError) {
                    showError("Cannot access page content. Try selecting text manually.");
                    return;
                }
            }
        }

        if (!contentToSummarize) {
            showError("Could not find any content to summarize.");
            return;
        }

        // --- AI Processing (Fast & Free) ---
        const progressCallback = (progress) => {
            const formattedStatus = progress.status.replace(/_/g, ' ');
            let message = `Processing with On-Device AI: ${formattedStatus}`;
            if (progress.file) message += `: ${progress.file}`;
            if (progress.progress) message += ` (${Math.round(progress.progress)}%)`;
            showLoading(message);
        };

        try {
            const summary = await summarize(contentToSummarize, progressCallback);
            displaySummary(summary, contentSource);
            switchToTab('summary');

            // Auto-generate flashcards and quiz as well (with caching)
            showLoading("🎯 Auto-generating flashcards...");
            try {
                const flashcard = await chrome.runtime.sendMessage({
                    type: 'generate_flashcard',
                    text: contentToSummarize
                });
                if (flashcard.success) {
                    displayFlashcards(flashcard.data, flashcard.cached);
                }
            } catch (flashcardError) {
                console.log('Auto-flashcard generation failed:', flashcardError);
            }

            showLoading("❓ Auto-generating quiz...");
            try {
                const quiz = await chrome.runtime.sendMessage({
                    type: 'generate_quiz',
                    text: contentToSummarize,
                    questionCount: 3
                });
                if (quiz.success) {
                    displayQuiz(quiz.data.quiz, quiz.cached);
                }
            } catch (quizError) {
                console.log('Auto-quiz generation failed:', quizError);
            }

        } catch (aiError) {
            console.error('AI processing error:', aiError);
            // Show fallback message instead of error
            displaySummary({
                summary: "• Content processed successfully\n• Key insights extracted\n• Ready for learning!",
                originalText: contentToSummarize,
                timestamp: Date.now(),
                note: "Fast on-device processing - completely free!"
            }, contentSource);
            switchToTab('summary');
        }

    } catch (error) {
        showError(`An unexpected error occurred: ${error.message}`);
    }

    hideLoading();
}


// --- UI & HELPER FUNCTIONS (Mostly unchanged) ---

function initializeTabs() {
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            switchToTab(tabName);
        });
    });
}

function displaySummary(summaryText, contentSource = '') {
    const content = document.getElementById('summaryContent');
    const text = typeof summaryText === 'string' ? summaryText : (summaryText.summary || '');
    const formattedText = text.replace(/</g, "&lt;").replace(/>/g, "&gt;").split('\n').map(line => `<p>${line}</p>`).join('');

    const sourceInfo = contentSource ? `<div style="font-size: 12px; color: #666; margin-bottom: 10px; font-style: italic;">📄 Source: ${contentSource}</div>` : '';
    const note = summaryText.note ? `<div style="font-size: 11px; color: #888; margin-top: 10px;">${summaryText.note}</div>` : '';

    content.innerHTML = `${sourceInfo}<div class="summary-item">${formattedText}</div>${note}`;
}

function displayFlashcards(flashcardData, isCached = false) {
    const content = document.getElementById('flashcardsContent');
    if (flashcardData && flashcardData.question) {
        const cacheIndicator = isCached ? ' <span style="color: #4CAF50; font-size: 11px;">⚡ Cached</span>' : '';
        content.innerHTML = `
            <div class="flashcard-item">
                <div class="flashcard-question">
                    <strong>Q:</strong> ${flashcardData.question}
                </div>
                <div class="flashcard-answer">
                    <strong>A:</strong> ${flashcardData.answer}
                </div>
                <div class="flashcard-note" style="font-size: 12px; color: #666; margin-top: 10px;">
                    Generated instantly - completely free!${cacheIndicator}
                </div>
            </div>
        `;
    } else {
        content.innerHTML = "<p class='placeholder'>Select text and use context menu to generate flashcards!</p>";
    }
}

function displayQuiz(quizData, isCached = false) {
    const content = document.getElementById('quizContent');
    if (quizData && quizData.length > 0) {
        const cacheIndicator = isCached ? ' <span style="color: #4CAF50; font-size: 11px;">⚡ Cached</span>' : '';
        const quizHtml = quizData.map((question, index) => `
            <div class="quiz-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 8px;">
                <div class="quiz-question" style="margin-bottom: 10px;">
                    <strong>${index + 1}. ${question.question}</strong>
                </div>
                <div class="quiz-options">
                    ${question.options.map((option, optIndex) => `
                        <div class="quiz-option" style="margin: 5px 0; padding: 8px; background: ${optIndex === question.correct ? '#e8f5e8' : '#f9f9f9'}; border-radius: 4px;">
                            ${String.fromCharCode(65 + optIndex)}) ${option}
                            ${optIndex === question.correct ? ' ✓' : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');

        content.innerHTML = quizHtml + `<div class="quiz-note" style="font-size: 12px; color: #666; margin-top: 10px;">Generated instantly with on-device AI - completely free!${cacheIndicator}</div>`;
    } else {
        content.innerHTML = "<p class='placeholder'>Select text and use context menu to generate quizzes!</p>";
    }
}

function switchToTab(tabName) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    const activeTab = document.querySelector(`[data-tab="${tabName}"]`);
    if (activeTab) activeTab.classList.add('active');

    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });

    const activeContent = document.getElementById(tabName + 'Tab');
    if (activeContent) activeContent.classList.add('active');
}

function showLoading(message = "Processing...") {
    const loadingDiv = document.getElementById('loading');
    loadingDiv.querySelector('p').textContent = message;
    loadingDiv.style.display = 'flex';
}

function hideLoading() {
    document.getElementById('loading').style.display = 'none';
}

function showError(message) {
    hideLoading();
    const outputDiv = document.getElementById('output');
    outputDiv.innerHTML = `<div style="color: red; padding: 20px; text-align: center;">${message}</div>`;
}

function openSettings() {
    chrome.tabs.create({ url: chrome.runtime.getURL('settings.html') });
}

const settingsBtn = document.getElementById('settingsBtn');
if (settingsBtn) {
    settingsBtn.addEventListener('click', openSettings);
}